import pandas as pd
from datetime import datetime
import os

# Simuler des données sportives du jour
data = {
    "Date": [datetime.now().strftime("%Y-%m-%d")]*3,
    "Pays": ["France", "Espagne", "Italie"],
    "Match": ["Paris SG vs Lyon", "Real Madrid vs Barça", "Milan vs Inter"],
    "Astuce": ["But rapide", "Under 1.5 MT", "+3 Cartons"]
}

df = pd.DataFrame(data)
os.makedirs("fichiers", exist_ok=True)
df.to_excel("fichiers/resultats.xlsx", index=False)